package router

import (
	"backend/app/controller/admininterface"
	"backend/app/controller/studentinterface"
	"backend/app/controller/userController"

	"github.com/gin-gonic/gin"
)

func Init(r *gin.Engine) {
	const pre = "/api"
	api := r.Group(pre)
	api.POST("/user/login", userController.Login)
	api.POST("/user/reg", userController.Register)
	api.POST("/student/post", studentinterface.Publish)
	api.PUT("/student/updata", studentinterface.Updata)
	api.DELETE("/student/post", studentinterface.Delete)
	api.GET("/student/posts", studentinterface.GetPosts)
	api.POST("/student/report-post", studentinterface.Report)
	api.GET("/student/report-post", studentinterface.CheckReport)
	api.GET("/admin/report", admininterface.GetAllReport)
	api.POST("/admin/report", admininterface.ApprovalAllReport)
}
