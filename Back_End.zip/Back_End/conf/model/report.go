package model

    type Report struct {
	ID      int       `json:"id"`
	UserID  int       `json:"userid"`
	PostID  int       `json:"postid"`
	Content string    `json:"content"`
	Reason  string    `json:"reason"`
	Status  int       `json:"status"`
}